import{_ as t}from"./RadarChart.vue_vue_type_script_setup_true_lang-00c31b29.js";import"./index-2ea4c758.js";import"./index-455b6c01.js";export{t as default};
