import{_ as e}from"./PieChart.vue_vue_type_script_setup_true_lang-240b82ba.js";import"./index-2ea4c758.js";import"./index-455b6c01.js";export{e as default};
